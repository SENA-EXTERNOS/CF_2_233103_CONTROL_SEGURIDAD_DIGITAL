function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6QWJWWzX2M6":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

