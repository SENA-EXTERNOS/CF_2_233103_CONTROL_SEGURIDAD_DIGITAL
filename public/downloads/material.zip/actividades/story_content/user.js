function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6iE8XBJ99Vi":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

